# P3.06 · Graph-integrity rules (GRP-001/002/003)

> Phase: [P3 — Rules](index.md) · Roadmap: [v2 Index](../index.md) · Size **M** · Status **Done**.

## Goal

Implement the three graph-integrity rules to reach lint parity. GRP-001/002 **consume the `ContextGraph` injected via `RuleContext.graph`** (built by the orchestrator, [P2.05](../P2-rule-engine/05-orchestration-lintfiles.md)); they do **not** build their own adjacency. In P3 the orchestrator uses the relocated legacy builder; [P4.06](../P4-graph/06-grp-refactor-coverage.md) swaps in the semantic `ContextGraph` ([R5](../requirements/02-rules-engine.md)/[G6](../requirements/03-context-graph.md)) with no change to this rule code (audit 2.2).

## Sequence

- **Previous:** [P3.01 — Shared rule utils](01-shared-rule-utils.md).
- **Next:** [P3.08 — custom rule](08-custom-rule.md), [P3.09 — cutover](09-rule-tests-and-cutover.md).
- **Depends on:** P3.01 + the relocated current graph build (cycle/orphan logic from [P0.04](../P0-foundations/04-relocate-current-source-into-core.md)) · **Blocks:** P3.08, P3.09 · **Refactored by:** [P4](../index.md) (R5/G6).

## Rules

| ID | Scope | Severity | Checks | Key options |
| --- | --- | --- | --- | --- |
| GRP-001 | project | error | no circular references | `minCycleLength?` (default 3) |
| GRP-002 | project | warning | every doc has ≥1 incoming ref (except entry points) | `files?`, `exclude?`, `entryPoints?` |
| GRP-003 | project | warning | ID chain across stages (stage N IDs appear at N+1) | `chain[{stage,files,idColumn?,refColumn}]`, `idPattern?` |

## Deliverables / steps

1. GRP-001 cycle detection (DFS color-marking / reuse the existing Tarjan SCC); canonicalize cycles to avoid duplicate reports; attribute to the first arc.
2. GRP-002 incoming-reference count with `entryPoints` allowlist + site-router resolution. **Superseded in part by [P11.13](../P11-remediation/13-grp-size-hygiene.md):** the key-options column above dropped the keys both rules accepted but ignored — GRP-001 kept no options at that point, and neither rule takes a per-rule `siteRouter` (the shared graph resolves routes from `settings.siteRouter`). GRP-002's `files`/`exclude` survive as reporting scope. **And in part by [P13.04](../P13-correctness/04-rule-option-defaults.md):** GRP-001 gained `minCycleLength` (default 3, so a two-document mutual link is not reported) — wireable where the removed keys were not, because it filters the rule's own findings rather than the corpus-wide graph — and GRP-002's `entryPoints` gained a default of `["README.md", "CLAUDE.md", "AGENTS.md", "index.md"]`.
3. GRP-003 chain traversal across stage files by ID/ref columns.
4. **Graph source (decided 2026-07-02, audit 2.2):** GRP-001 reads the graph's explicit cycle list and GRP-002 reads node `inDegree` from `RuleContext.graph` — **no local adjacency in rule code**. The orchestrator ([P2.05](../P2-rule-engine/05-orchestration-lintfiles.md)) builds and injects that graph: the relocated legacy builder in P3, the semantic `buildContextGraph` from [P4.06](../P4-graph/06-grp-refactor-coverage.md) later. Because the rules code against the injected graph's read shape, only the builder changes in P4 — rule code and its (output-focused) tests stay put. GRP-003 is graph-independent: it walks the `chain[]` ID/ref columns directly.

## Decisions applied

- [C5](../requirements/01-configuration.md) site-router · [R5](../requirements/02-rules-engine.md) (refactor target) · [G6](../requirements/03-context-graph.md) explicit cycles.

## Exit criteria

Recorded rather than tracked: this task predates the convention that the landing change ticks its own criteria, so the lines below are the bar it was written against, not a live checklist. Phase completion is carried by the [phase index](index.md); the reasoning is in the [completion surface](../completion-surface.md).

- GRP-001/002/003 pass unit + fixture tests (cycles, orphans, broken chains).
- Cycle reports are de-duplicated and attributed.

## Hand-off to next

Lint parity is reachable; P4 unifies these onto the shared graph so the cycle/orphan logic lives in exactly one place.
