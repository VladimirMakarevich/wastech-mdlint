# P6.04 · Config writer + local `$schema` wiring

> Phase: [P6 — init](index.md) · Roadmap: [v2 Index](../index.md) · Size **M** · Status **Done**.

## Goal

Write the final config and wire it to the **local** schema, optionally dropping a CI workflow.

## Sequence

- **Previous:** [P6.03 — Interactive prompts](03-interactive-prompts.md) (confirmed selections).
- **Next:** [P6.05 — init tests](05-init-tests.md).
- **Depends on:** P6.03 + schema generator ([P2.06](../P2-rule-engine/06-schema-generation.md)) · **Blocks:** P6.05.

## Deliverables / steps

1. Write `wastech-mdlint.config.json` in `cwd`: `$schema` (local path), `include`/`exclude`, and `rules` using **canonical IDs** ([C3](../requirements/01-configuration.md)); optionally add rationale **comments** (JSONC, [C4](../requirements/01-configuration.md)). On **merge** ([P6.03](03-interactive-prompts.md), audit — P6 merge gap) apply _additive, existing-wins_: preserve every existing `rules[]` entry (severity/options) and only append inferred rules whose canonical ID is absent; do not touch existing `include`/`exclude`/`settings`.
2. **Schema wiring** ([I3](../requirements/06-installation.md)/[C9](../requirements/01-configuration.md)): default `$schema` to the local package path; if custom rules exist, call the frozen `generateConfigSchema({ customRules })` ([P2.06 frozen API](../P2-rule-engine/06-schema-generation.md), audit 4.1) to write a project-local schema and point `$schema` there. **No remote URL.** (**Superseded by [P11.14](../P11-remediation/14-init-cli-lows.md):** the project-local schema is also written when no package schema is installed to point at, and an existing `schema.json` is never replaced — not even under `--on-existing overwrite` when that fallback is the only reason for it.)
3. Optional ([I6](../requirements/06-installation.md)): offer to drop `.github/workflows/wastech-mdlint.yml` — ask first, don't write silently. **Shipped as a self-contained workflow** (`npm install --no-save @wastech-mdlint/cli` + `npx wastech-mdlint lint …`) rather than a `uses:` reference to the first-class composite Action: that Action is [PR.03](../P-release/03-github-action.md) (Not started), so a `uses:` template would be a dead workflow when P6 lands. [PR.03](../P-release/03-github-action.md) also owns swapping this template to the published `uses:` form once the Action exists. The workflow is anchored at the repository root (where GitHub loads workflows) and, for a subdirectory config, scopes lint to the config's directory and passes `--config` (both single-quoted) so the run resolves `include`/`exclude` against the right tree. (**Amended by [P14.04](../P14-host-boundary/04-config-resolution-base.md):** the two arguments are anchored differently on purpose — `[path]` stays repo-root-relative because the workflow runs from the repository root, while `--config` is now the config's **basename**, since the CLI resolves a relative `--config` against `[path]`. A root-relative `--config` would send the generated workflow looking for `<dir>/<dir>/…` and fail its first run.) The template is deliberately npm-universal regardless of the repo's detected package manager (bun/pnpm/yarn/npm) — see [P9.07](../P9-remediation/07-init-ci-package-manager.md).
4. Print a summary of what was written (repository-relative POSIX paths).

## Decisions applied

- [C3](../requirements/01-configuration.md), [C4](../requirements/01-configuration.md), [C9](../requirements/01-configuration.md) · [I3](../requirements/06-installation.md), [I6](../requirements/06-installation.md).

## Exit criteria

- [x] Valid config written with canonical IDs + local `$schema`; no remote URL.
- [x] Project schema generated when custom rules are present. **Superseded by [P11.14](../P11-remediation/14-init-cli-lows.md):** it is also generated when there is no installed package schema to point at (the `npx` case), so the written `$schema` never dangles.
- [x] CI workflow offered (opt-in), not written silently.

## Implementation notes

Decisions that are load-bearing but not obvious from the code:

- **Core generates text, the CLI writes files.** `generateInitConfig` (core) is pure and fs-free — it returns the config bytes, the resolved `$schema`, and (whenever `$schema` names it — see the P11.14 notes above) the project schema; `init-command.ts` performs the actual `writeFile`s, and owns the guard on replacing an existing one. Same split as `compile`/`schema`.
- **Fresh writes always emit `exclude`.** The scanner deliberately prunes noise directories (`node_modules`, `.git`, `dist`, …), so the written config carries them as an `exclude` list — otherwise a config whose `include` falls back to `**/*.md` would re-scan exactly the trees init ignored (C1). `merge` never touches an existing `exclude`. **Extended by [P11.14](../P11-remediation/14-init-cli-lows.md):** the scan also prunes hidden and gitignored trees, so a fresh write adds a hidden-directory glob to `exclude` and an explicit `respectGitignore: true` (a `merge` adds neither). **Narrowed by [P14.03](../P14-host-boundary/03-init-disclosure.md):** the hidden-directory glob half is gone — a fresh write now emits only the noise names (12 globs, `.venv`/`.yarn` added in its place) plus that explicit `respectGitignore: true`, and the draft _discloses_ the scan's hidden-tree prune rather than encoding it (W-14/W-15).
- **Merge is validated through the real loader before writing.** Additive merge preserves the existing content verbatim, so the result is only valid if the existing config already loads. The merge path runs `loadConfiguration` on the existing file and aborts (writes nothing) on an unknown top-level key, unknown rule id, or invalid preserved options — the acceptance bar is a _valid_ config, and reporting success while writing one the loader rejects would violate it.
- **Merge safety keys entries by identity, not the literal `rule` field.** A built-in is identified by its canonical `rule`; a `custom` entry by its canonical `id` (never the string `"custom"`). A merge aborts when any entry can't be canonically identified — a bare string, a non-string `rule`, or a `custom` entry with a missing/non-string/non-schemaable `id` — because an unidentifiable entry can't be diffed against the inferred set without risking a silent duplicate.
- **`$schema` and workflow anchor on discovered roots, not fixed literals.** `$schema` is computed relative to the config's own directory (anchored on the actual installed `schema.json`), so a subdirectory config points up at the hoisted `node_modules` (`../node_modules/…`). **Superseded by [P11.14](../P11-remediation/14-init-cli-lows.md):** there is no repo-root fallback any more — with nothing installed the CLI passes `undefined` and the writer generates a project-local `./schema.json`, because the old fallback anchored on a `node_modules` path that did not exist. The workflow anchors at the `.git` root when one exists (a nested workspace package still anchors at the real repo root, not `packages/foo`), falling back to the nearest `package.json`/`node_modules` outside git.
- **`skip` is a strict no-write outcome**, and a Ctrl+C at the _post-write_ CI-workflow prompt is treated as "no workflow" (the config/schema are already on disk, so the write summary must still print rather than the whole command unwinding to look like a no-op).
- **CI template is self-contained, not `uses:`** — see deliverable 3; `buildCiWorkflowYaml` is the single swap point once [PR.03](../P-release/03-github-action.md) publishes the Action.
- **CI template is npm-universal by design**, not a discarded detection. `runInitCommand` detects bun/pnpm/yarn/npm (via `packageManager` in the draft summary) but never threads it into `buildCiWorkflowYaml`: the install step only fetches the external `@wastech-mdlint/cli` tool, never the target repo's own dependencies, so it never touches that repo's lockfile/workspace resolution; `actions/setup-node` already provides npm on every runner, so branching per manager would only add setup steps for no functional benefit. See [P9.07](../P9-remediation/07-init-ci-package-manager.md).

## Hand-off to next

P6.05 verifies the written config lints cleanly; P8's `-init` skill calls this CLI `init` and adds the README/GitHub Actions orchestration on top.
