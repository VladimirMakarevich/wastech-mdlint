# P17.06 · Register contract and roadmap accuracy

> Phase: [P17 — Plan of record](index.md) · Roadmap: [v2 Index](../index.md) · Size **S–M** · Status **Done**. Depends on [P17.04](04-completion-surface.md).

## Goal

Make the accepted-behaviors register satisfy its own contract — it is where every **decision** item in this backlog terminates — and clear the last three roadmap and documentation inaccuracies.

## Problem

**W-48 — the register fails its own three rules, at three sites.**

1. Row `:24` names `docs/guide/output.md` as the home of the leftover-`schema.json` behavior. That page's **only** occurrence of the word "schema" is in the `helpUri` row, about the MCP `outputSchema` — nothing there states this behavior. (The backlog says "zero occurrences"; that was true when it was written and the one occurrence has since arrived from an unrelated change, so re-verify by reading the page rather than by counting.) The behavior **is** stated for users, on `docs/guide/cli.md` in the `init` `$schema` bullets at `:140`–`:141` — so the defect is the pointer, not a missing home.
2. The id-ref-inside-a-code-fence inflation was accepted **twice in task files** (`P4-graph/01-context-graph-model.md:51` and `P9-remediation/08-idref-prose-scan.md`) and has no row, though it inflates `impact`, `slice`, and `GRP-002`.
3. Dangling reference-style links invisible to `REF-001` were accepted and given a README home (`README.md:239`), but never a row.

All three re-verified in the current tree after P13–P16.

**Consequence:** `P12-consistency/06-process-boundary-tests.md:72` claims each accepted behavior has a home "confirmed to exist and to state it". Site 1 falsifies that.

**And the register flags one row against itself.** The `init`-draft row — the draft a user confirms does not name the project-local `schema.json` the `npx` path writes, only the after-the-fact write summary does — is marked **deferred rather than accepted**, and its own reason column calls it "the one row here a future task should close rather than keep". It is a gap against the warn-before-confirming discipline, not a behavior anyone chose. It now sits in the **Recorded residuals** table at `:61` (the backlog's `:39` citation predates the rows P13–P16 added; locate it by its text). Leaving a self-flagged row untouched while fixing the register's other three failures is the one outcome to avoid.

**W-49 — live Prettier corruption in a phase task file.** `P7-mcp-server/02-lint-tools.md:35` has been destructively rewritten where a glob-bearing code span was nested inside a bold span: the inline delimiters were eaten and the sentence is unreadable as authored (`**/_.md` where `**/*.md` was written, with the surrounding spacing collapsed). `proseWrap: "never"` is why the gate cannot see it — **the format gate passes on the damage.** The class grep returns exactly one site.

**W-51a — the roadmap and the glossary disagree about milestone M4.** `index.md`'s §7 milestone list assigns "P6, P8, then P9/P10, P11/P12 and P13–P17 (three post-audit remediation rounds), then P-release" to M4; the glossary's **Milestone (M1–M4)** entry still reads "(P6, P8, then P9/P10 and P11/P12, then P-release)" — P13–P17 missing. Same class as W-51, introduced by the change that created these phases rather than by the original rename, so it is swept here.

**W-51 — two roadmap inaccuracies.** `index.md:17` and the target tree at `:83` list six CLI commands; a **seventh, `schema`, ships** and is mandated by its own task file, by requirement C9, and by the glossary — so under the stated precedence the roadmap summary is the defect, not the code. And `:87` diagrams `schema.json` at the repository root; it has only ever lived at `packages/cli/schema.json`, which the installed-path constant and the CLI's `files` allowlist both require.

**W-52 — the frozen audits are in Russian (note).** The QA pass disputed the value of this item, noting the repository owner is a Russian speaker and no rule requires English. The fact that makes it more than style: those two files are the **definition site** for the finding IDs four phases are written in, and nothing else defines them. `.agents/rules/testing.md:29` rests the four boundary-guard categories on the second report's systemic-cause section; the two release blockers cited in `P11-remediation/index.md` are defined only there; and the glossary's **Phase** entry derives all three remediation rounds from the three assessments by name. The backlog's third citation, `AGENTS.md:47`, **no longer exists** — see W-52a below, which is where that deletion is handled.

**W-52a — an unrecorded governance deletion, found while auditing this phase.** Commit `add1ee5`, the same commit that added the backlog, also removed content nothing asked it to:

1. **`AGENTS.md`'s entire `## Delivery Order` section** — the `P0 → … → P-release` order, the sentence deriving P9–P12 from the two audits by name (the backlog's `AGENTS.md:47`), and "respect each task file's `Previous`, `Next`, `Depends on`, and `Blocks` links". The phase order survives in [`.agents/rules/architecture.md`](../../../.agents/rules/architecture.md); the audit derivation and the task-chain rule survive nowhere.
2. **The glossary's entire preamble** — its `> **Status:**` header (every other plan document has one), "How to use this glossary", the "Shipped vs planned" roll-up (W-42's `:12`), and the **Maintenance rule**. [`CLAUDE.md`](../../../CLAUDE.md) still instructs the reader to "see the glossary's maintenance rule", which is now a pointer to deleted text — and both `AGENTS.md` and [`.agents/rules/coding-style.md`](../../../.agents/rules/coding-style.md) restate that rule while the glossary itself no longer carries it.

This is W-44's mechanism exactly — a load-bearing document removed as a side effect of an unrelated commit — one round later, and it is not in the backlog because the backlog was committed alongside it. It also **left the format gate red at `HEAD`**: the deleted preamble stranded a double blank line under the glossary's heading, so `prettier --check .` failed on a committed file. That one line is already fixed (it blocked every other commit); the rest of this item is the work below.

## Deliverables / steps

1. **W-48:** repoint row `:24` at the `init` `$schema` bullets on `docs/guide/cli.md`, and add the two missing rows.
2. **W-48 — dispose of the self-flagged `init`-draft residual.** Close it (name the schema in the `init` draft — a small [`init-command.ts`](../../../packages/cli/src/init-command.ts) change, which makes this task `docs, code` rather than docs-only) or re-classify it as genuinely accepted with a stated reason.
3. **W-48 — this is where the phase's decisions land, and they have all landed.** Every **decision** item across P13–P16 terminated here as an accept, and the rows already exist: `GRP-001`'s two-node floor and `GRP-002.entryPoints` replace-not-extend ([P13.04](../P13-correctness/04-rule-option-defaults.md), rows `:35`–`:37`), the hidden-directory default and `compile`'s own outdir ([P14.03](../P14-host-boundary/03-init-disclosure.md), `:26`–`:27`), the MCP schema-rejection and `OPERATIONAL_ERROR` path bounds ([P14.05](../P14-host-boundary/05-mcp-error-contract.md), `:39`–`:40`), the role vocabulary and the cycle elision ([P15.01](../P15-output-contracts/01-renderers-at-scale.md), `:41`–`:42`, `:45`), the `engines` floor ([P16.03](../P16-release-readiness/03-published-payload.md), `:50`), and `init`'s 8-of-24 inference ([P16.05](../P16-release-readiness/05-low-severity-cleanups.md), `:49`, plus a re-homed residual at `:62`). So this step is **verification, not authoring**: open each row's cited page and confirm it states the behavior, rather than reading the pointer — a plausible-looking pointer is site 1's exact failure mode. Add a row only where a decision has none.
4. **W-48 — and one row must be deleted, not verified.** [P16.01](../P16-release-readiness/01-test-debt.md) added a residual recording that the glossary's `lintFiles` entry and the enforced ADR disagree; [P17.03](03-adr-and-dependency-register.md) closes that divergence and is instructed to remove the row. Confirm it is gone rather than stale — the register's own rule is delete, not annotate.
5. **W-49:** retype the corrupted line, avoiding the construct. The standing rule already exists in the backlog and in `AGENTS.md`; this is the live instance.
6. **W-51:** add `schema` to both command lists at `index.md:17` and `:83`, and move `schema.json` in the tree diagram at `:87` to `packages/cli/`.
7. **W-51a:** bring the glossary's **Milestone (M1–M4)** entry in line with the roadmap's §7 list by adding P13–P17 to M4.
8. **W-52a — restore what `add1ee5` dropped, deliberately rather than by revert.** The glossary's `> **Status:**` header and its **Maintenance rule** come back (the rule is quoted in three governance files, so the canonical statement belongs in the document they point at); the "Shipped vs planned" roll-up does **not** need restoring as a second roll-up — [P17.04](04-completion-surface.md) maintains the surviving **Phase** entry, and reintroducing a duplicate would recreate W-42's two-places-to-drift shape. For `AGENTS.md`, decide where the two orphaned statements live: the audit-to-phase derivation (needed by W-52's argument) and the `Previous`/`Next`/`Depends on`/`Blocks` task-chain rule, which `.agents/rules/architecture.md` states only for `Depends on`-style chains. Whatever is chosen, `CLAUDE.md`'s pointer must resolve when this task is done.
9. **W-52 — cheapest sufficient option:** one line at each report's head stating the language, plus an English rendering of the two finding tables — the parts the plan actually cites. Or record the choice, since the audits are frozen by policy. **Not a blocker for anything**, and the QA pass's disagreement about its value should be recorded alongside whatever is done.
10. **Update `P12-consistency/06-process-boundary-tests.md:72`** if its claim is still not literally true after the register is fixed.

## Out of scope

Rewriting the frozen audit reports. Adding register rows for behaviors nobody accepted — the register indexes decisions, and inventing rows to make it look complete is the inverse of this task's point.

## Exit criteria

- [x] Row `:24` points at a page that states the behavior; the two missing rows exist.
- [x] The self-flagged `init`-draft residual is closed in code or re-classified with a reason.
- [x] Every P13–P16 decision that resolved to "accept" has a register row whose user-facing home was **opened and read**, not just linked.
- [x] The `lintFiles`-versus-ADR residual is gone from the register, deleted rather than annotated.
- [x] `P7-mcp-server/02-lint-tools.md:35` reads as authored, and the format gate is green on it.
- [x] The roadmap lists seven CLI commands and diagrams `schema.json` under `packages/cli/`.
- [x] The glossary's **Milestone** entry and the roadmap's §7 list agree about M4 (W-51a).
- [x] The glossary carries a `Status` header and the **Maintenance rule** again, `AGENTS.md`'s two orphaned statements have a home, and `CLAUDE.md`'s "see the glossary's maintenance rule" pointer resolves (W-52a).
- [x] Each frozen audit states its language, or the choice is recorded with the disagreement noted.
- [x] `P12.06`'s "confirmed to exist and to state it" claim is true or corrected.
- [x] `npm run format` green.

## Implementation notes

**The verification pass found a second instance of site 1's failure mode, and it was not in the list.** Every P13–P16 decision row's cited home was opened and read (not merely resolved — a link checker over the whole register reports zero broken links and zero broken anchors, which is exactly why the mechanical check cannot substitute for reading). Two rows failed on content:

- The **`helpUri` → `blob/main`** row cited `output.md`'s `helpUri` table row, which described what the field holds and its declared-optional nullability but said nothing about the `blob/main` base or its consequence for a pinned install. [P15.03](../P15-output-contracts/03-lint-output-contract.md)'s own notes say "that is a register row, not a silent trade" — the row was written, the home was not. Fixed by stating it in that table row, which is where the register already pointed.
- The **`init` 8-of-24** row listed [SIZE-001](../../guide/rules/SIZE-001.md) and [LLM-001](../../guide/rules/LLM-001.md) beside `cli.md#init`. Neither rule page mentions `init` at all; they are the pages the draft sends you to, not a second statement of the inference boundary. Trimmed to the one home that states it, which links both pages itself.

That is two page-level pointers that read as confirmation in three separate reviews, so the fix is a rule rather than three edits: the register's **How to use it** now requires citing the section carrying the sentence, and says that verifying a row means opening it. `P12.06`'s claim is true again and carries the correction inline.

**The self-flagged residual was closed in code, not re-classified.** The draft now carries a `Schema:` line — the ref the config will hold, plus the filename and reason when `init` has to generate one — so the `npx` path's second file is visible while declining is still possible. This required generating the config **before** the draft rather than after it ([`init-command.ts`](../../../packages/cli/src/init-command.ts)); generation is pure, so the only behavioral difference is that the installed-schema lookup now also runs on a declined run, and the same `GeneratedInitConfig` is what gets written, so the draft and the write summary cannot describe different files. Guarded end to end by position in [`init.e2e.test.ts`](../../../packages/cli/test/init.e2e.test.ts) — under `--yes` both documents print, so the assertion is that the draft's mention comes **first**.

**W-49's standing rule was in the backlog only.** This task file said it "already exists in the backlog and in `AGENTS.md`"; `grep` for it in `AGENTS.md`, `CLAUDE.md` and `.agents/rules/` returned nothing — the backlog is a work-item document that gets superseded, so the rule was one deletion away from being lost with the live instance still in the tree. It is now stated in `AGENTS.md` beside the `proseWrap` rule, with the property that makes it dangerous: **`prettier --check` passes on the damage**, because the formatter produced it.

**W-52a — what came back and what deliberately did not.** The glossary's `Status` header and **Maintenance rule** are restored, the rule marked as the canonical statement the three governance files point at. The "Shipped vs planned" roll-up is **not** restored: [P17.04](04-completion-surface.md) maintains the surviving **Phase** entry, and a second roll-up is precisely W-42's two-places-to-drift shape — the preamble now says so, so the absence reads as a decision rather than an oversight. "How to use this glossary" is also not restored: nothing points at it, its two still-useful conventions are one sentence in the Status block, and its third bullet _was_ the roll-up. `AGENTS.md` gets its `## Delivery Order` section back, rewritten rather than reverted: the phase order now defers to [`.agents/rules/architecture.md`](../../../.agents/rules/architecture.md) instead of restating it (the restatement is what went stale), while the two statements that survived nowhere — the task-chain rule and the audit-to-phase derivation — are stated there, the derivation extended to name the third assessment and to say why the three reports are frozen.

**W-52 — language stated, findings indexed, audits untouched.** Each report carries a `Language / Язык` line at its head explaining that it is Russian and frozen, and an appended **Appendix A: English finding index** — one row per finding ID, plus an English rendering of the second report's section 4, which is what [`.agents/rules/testing.md`](../../../.agents/rules/testing.md) rests the four boundary-guard categories on. The Russian bodies are byte-unchanged: an index is additive, a translation would replace the definition site the P9–P12 task files are written against, which this task holds out of scope. The appendices say they are glosses and that the Russian entry stays authoritative.

**The QA pass's disagreement, recorded as asked.** It disputed W-52's value — the repository owner is a Russian speaker and no rule requires English — and on the narrow question of whether the reports must be English, it is right; nothing here asks them to be. What the item is actually about is that four phases are written in finding IDs these two documents alone define, so an English reader of the plan has no way to resolve `M-2` or `H-1`. An index answers that at a fraction of the cost of a translation and without touching the frozen text, which is why the cheap option was taken rather than either the expensive one or none.
