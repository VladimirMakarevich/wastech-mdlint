# Phase P0 — Workspace & Foundations

> Roadmap: [v2 Index](../index.md) · Phase **P0** · Size **M** · Status **Done**
>
> **Goal:** stand up the monorepo and shared tooling so every later phase lands in the right package, then lift-and-shift the current implementation into `@wastech-mdlint/core` **without changing its behavior**. P0 ships no new product features — it is purely structural.

## Why this phase exists

The current implementation is a single package with a hand-rolled CLI. The target ([D1](../index.md)) is a workspace with `@wastech-mdlint/{core,cli,mcp-server}` so the MCP server and CLI publish separately and all hosts import one core ([core-hosts-the-pipeline](../decisions/core-hosts-the-pipeline.md)). Everything in [P1+](../index.md) (parser upgrade, rule engine, graph, compile, MCP) assumes this layout already exists.

## Tasks

| # | Task | Size | Depends on |
| --- | --- | --- | --- |
| [P0.01](01-workspace-decisions.md) | Workspace layout & tooling decisions (design) | S | — |
| [P0.02](02-root-scaffolding.md) | Root workspace + shared config baseline | M | P0.01 |
| [P0.03](03-core-package-skeleton.md) | `@wastech-mdlint/core` package skeleton | S | P0.02 |
| [P0.04](04-relocate-current-source-into-core.md) | Relocate current source into core (behavior-preserving) | M | P0.03 |
| [P0.05](05-cli-package-commander.md) | `@wastech-mdlint/cli` + commander scaffold (port scan/graph) | M | P0.04 |
| [P0.06](06-mcp-server-skeleton.md) | `@wastech-mdlint/mcp-server` package skeleton (stub) | S | P0.04 |
| [P0.07](07-ci-packaging-baseline.md) | CI matrix & packaging/publish baseline | M | P0.05, P0.06 |
| [P0.08](08-exit-verification.md) | Phase exit verification & layout docs | S | all above |
| [P0.09](09-audit-remediation.md) | Phase P0 audit & remediation (requirements + codebase) | M | P0.08 |

## Sequence

```
P0.01 ─► P0.02 ─► P0.03 ─► P0.04 ─┬─► P0.05 ─┐
                                  └─► P0.06 ─┴─► P0.07 ─► P0.08 ─► P0.09 ─► (Phase P1)
```

P0.05 (cli) and P0.06 (mcp-server) both depend only on P0.04 and can run in parallel. P0.09 re-audits the phase after P0.08 declares it complete; it was run as an orchestrator task and went unlisted here until the [completion surface](../completion-surface.md) was reconciled.

## Decisions applied

- [D1](../index.md) monorepo (npm workspaces) · [D5](../index.md) commander + inquirer · [D2](../index.md) clean config replace (greenfield) · [I1](../requirements/06-installation.md) drop `postinstall` · [I5](../requirements/06-installation.md) per-package supply chain.

## Phase exit criteria

- [x] `npm run typecheck && npm test && npm run build` are green across the whole workspace.
- [x] `packages/{core,cli,mcp-server}` exist with correct names, bins, and `publishConfig`.
- **Retired — permanently unverifiable.** Current behavior preserved: `wastech-mdlint scan` and `graph` produce the same output as before the migration (parity check). The pre-migration implementation this diffs against was removed at the P3.09 cutover and no test stands in for it, so nobody can run the comparison again. It was ticked here while the same criterion sat open in [P0.08](08-exit-verification.md) and [P0.09](09-audit-remediation.md); the tick was the false claim, and all three phase-/verification-level sites are retired rather than swept ([P0.05](05-cli-package-commander.md) states the same check as a delivery criterion and is stripped with the rest of P0–P3 instead — see the [completion surface](../completion-surface.md)).
- [x] The current `postinstall` auto-config is removed (I1).
- [x] CI runs the workspace matrix on Node 24; `npm pack --dry-run` is clean per package.
- [x] No new product features were added (P0 is structural only).

## What P0 unblocks

- **P1** — extend the relocated parser into `ParsedDocument` (in `core`).
- **P2** — build the rule engine + new config model (in `core`).
- **P7** — fill the `mcp-server` stub with real tools.
- **P-release** — turn the packaging baseline into the single-tag release workflow.
